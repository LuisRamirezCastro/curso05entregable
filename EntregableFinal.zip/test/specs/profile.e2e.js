//const { defaultUser, defaultSpecialities } = require('../helpers/data.helper');

const HomePage = require('../pageobjects/home.page');
const SearchPage = require('../pageobjects/search.page');

describe('Profile Page Tests', () => {
    
    before( () =>{
        
    })

    beforeEach( () => {
        //browser.reloadSession();
        //HomePage.open();
    })
    
    it.skip('Profile Page 1.a. Webservice is called when entering profile page', () => {
        
        console.log('//- - - - - > TODO')        
    });

});


